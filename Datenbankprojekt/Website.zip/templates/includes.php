<link rel="stylesheet" href="./resources/styles/global.css">
<link rel="stylesheet" href="./resources/styles/layout.css">
<link rel="stylesheet" href="./resources/styles/search.css">
<link rel="stylesheet" href="./resources/styles/utility.css">