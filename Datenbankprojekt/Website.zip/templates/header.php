<header>
    <ul>
        <li class="<?php echo ($_SERVER['PHP_SELF'] == "/index.php" ? "active" : "");?>"><a href="./index.php">BEGRIFFE</a></li>
        <li class="<?php echo ($_SERVER['PHP_SELF'] == "/search.php" ? "active" : "");?>"><a href="./search.php">SUCHE</a></li>
        <li class="<?php echo ($_SERVER['PHP_SELF'] == "/add.php" ? "active" : "");?>"><a href="./add.php">EINFÜGEN</a></li>
    </ul>
</header>