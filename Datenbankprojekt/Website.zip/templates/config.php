<?php

class Config {

    public static $HOST = 'localhost';
    public static $DB_NAME = 'it-terms';
    public static $USERNAME = 'shieeshkröte';
    public static $PASSWORD = 'spiegelei';

}

?>