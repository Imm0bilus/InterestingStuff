<footer>
    <span>&copy; Eschbacher Jonas & Hechenberger Jürgen</span>
</footer>